import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, ActivityIndicator, Alert, Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import {
  HelpCircle, Settings, Camera, Zap, FileUp,
  BarChart3, AlertTriangle, ArrowRight, Cpu, X,
  Microscope, FileText, Image as ImageIcon, FolderOpen,
} from 'lucide-react-native';
import { mlService } from '../../hooks/use-ml-service';

// ─── Types ─────────────────────────────────────────────────────────────────────
type ViewState = 'home' | 'camera';

const THEME = {
  primary:       '#00478d',
  secondary:     '#4f5f7b',
  background:    '#f7f9fb',
  surface:       '#ffffff',
  text:          '#191c1e',
  textSecondary: '#424752',
  border:        '#e0e3e5',
  cardBg:        '#f2f4f6',
  blood:         '#c0392b',
};

const { width } = Dimensions.get('window');

// ─── Document Scanner Screen ───────────────────────────────────────────────────
export default function ScannerScreen() {
  const [viewState,   setViewState]   = useState<ViewState>('home');
  const [isCapturing, setIsCapturing] = useState(false);
  const [flashOn,     setFlashOn]     = useState(false);
  const [modelStatus, setModelStatus] = useState(mlService.getStatus());

  const [permission, requestPermission] = useCameraPermissions();
  const cameraRef = useRef<any>(null);

  useEffect(() => {
    (async () => {
      await mlService.initialize();
      setModelStatus(mlService.getStatus());
    })();
  }, []);

  // ─── Helpers ──────────────────────────────────────────────────────────────

  const ensureCameraPermission = async (): Promise<boolean> => {
    if (permission?.granted) return true;
    const result = await requestPermission();
    if (!result.granted) {
      Alert.alert(
        'Camera Permission Required',
        'Please allow camera access in your device settings.',
        [{ text: 'OK' }],
      );
      return false;
    }
    return true;
  };

  /** Open live document camera */
  const openCamera = async () => {
    if (!(await ensureCameraPermission())) return;
    setFlashOn(false);
    setViewState('camera');
  };

  /** Capture photo and run OCR model */
  const handleCapture = async () => {
    if (isCapturing || !cameraRef.current) return;
    setIsCapturing(true);
    try {
      const photo = await cameraRef.current.takePictureAsync({ quality: 0.85, base64: false });
      console.log('Document photo captured:', photo.uri);
      await runInference(photo.uri);
    } catch (e) {
      console.error('Capture failed:', e);
      Alert.alert('Capture Failed', 'Could not process the image. Please try again.');
    } finally {
      setIsCapturing(false);
    }
  };

  /** Pick a document image from gallery */
  const handlePickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission Required', 'Please allow photo library access in settings.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.9,
      allowsEditing: false,
    });
    if (result.canceled || !result.assets?.length) return;
    await runInference(result.assets[0].uri);
  };

  /** Pick a PDF / document from storage */
  const handlePickDocument = async () => {
    const result = await DocumentPicker.getDocumentAsync({
      type: ['application/pdf', 'image/*'],
      copyToCacheDirectory: true,
    });
    if (result.canceled || !result.assets?.length) return;
    await runInference(result.assets[0].uri);
  };

  /** Run OCR inference */
  const runInference = async (uri: string) => {
    try {
      const result = await mlService.runInference('ocr', { imageUri: uri });
      console.log('OCR Result:', result);
      setViewState('home');
      router.push('/result');
    } catch (e) {
      console.error('Inference failed:', e);
      Alert.alert('Analysis Failed', 'Could not analyze the document. Please try again.');
    }
  };

  // ─── Camera View ───────────────────────────────────────────────────────────
  if (viewState === 'camera') {
    return (
      <View style={styles.cameraContainer}>
        <CameraView
          ref={cameraRef}
          style={styles.camera}
          facing="back"
          enableTorch={flashOn}
        >
          {/* Top bar */}
          <SafeAreaView style={styles.cameraTopBar}>
            <TouchableOpacity style={styles.camIconButton} onPress={() => setViewState('home')}>
              <X color="#fff" size={24} />
            </TouchableOpacity>

            <View style={styles.modePill}>
              <FileText color="#fff" size={14} />
              <Text style={styles.modePillText}>DOCUMENT</Text>
            </View>

            <TouchableOpacity
              style={[styles.camIconButton, flashOn && styles.camIconButtonActive]}
              onPress={() => setFlashOn(!flashOn)}
            >
              <Zap color={flashOn ? THEME.primary : '#fff'} size={24} />
            </TouchableOpacity>
          </SafeAreaView>

          {/* Rectangular reticle for documents */}
          <View style={styles.reticleOverlay}>
            <View style={[styles.reticleRect, isCapturing && styles.reticleActive]}>
              <View style={[styles.corner, styles.topLeft]}     />
              <View style={[styles.corner, styles.topRight]}    />
              <View style={[styles.corner, styles.bottomLeft]}  />
              <View style={[styles.corner, styles.bottomRight]} />
              {isCapturing && <View style={styles.scanLine} />}
            </View>
            <Text style={styles.reticleHint}>
              Align the document within the frame
            </Text>
          </View>

          {/* Shutter controls */}
          <View style={styles.cameraControls}>
            {/* Gallery shortcut */}
            <TouchableOpacity
              style={styles.camIconButton}
              onPress={() => { setViewState('home'); handlePickImage(); }}
            >
              <ImageIcon color="#fff" size={24} />
            </TouchableOpacity>

            {/* Main shutter */}
            <View style={styles.shutterOuter}>
              <TouchableOpacity
                style={[styles.shutterInner, isCapturing && styles.shutterActive]}
                onPress={handleCapture}
                disabled={isCapturing}
              >
                <View style={styles.shutterCore}>
                  {isCapturing
                    ? <ActivityIndicator color={THEME.primary} size="large" />
                    : <Camera color={THEME.primary} size={32} />}
                </View>
              </TouchableOpacity>
            </View>

            {/* Switch to Blood scanner */}
            <TouchableOpacity
              style={styles.camIconButton}
              onPress={() => router.replace('/scan')}
            >
              <Microscope color="#fff" size={24} />
            </TouchableOpacity>
          </View>
        </CameraView>
      </View>
    );
  }

  // ─── Home / Dashboard View ─────────────────────────────────────────────────
  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.brand}>
          <BarChart3 color={THEME.primary} size={24} />
          <Text style={styles.brandText}>HEMO-EDGE</Text>
        </View>
        <View style={styles.headerActions}>
          <View style={styles.modelIndicator}>
            <Cpu color={modelStatus.ocrLoaded ? THEME.primary : '#ff4444'} size={16} />
            <Text style={[styles.modelText, { color: modelStatus.ocrLoaded ? THEME.primary : '#ff4444' }]}>
              {modelStatus.ocrLoaded ? 'MODELS READY' : 'LOADING...'}
            </Text>
          </View>
          <TouchableOpacity style={styles.iconButton}>
            <HelpCircle color={THEME.textSecondary} size={24} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconButton}>
            <Settings color={THEME.textSecondary} size={24} />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.titleSection}>
          <Text style={styles.title}>Scan</Text>
          <Text style={styles.subtitle}>Choose a camera mode or pick a file from storage.</Text>
        </View>

        {/* ── Camera Mode Cards ────────────────────────────────────────── */}
        <Text style={styles.sectionLabel}>CAMERA</Text>
        <View style={styles.cameraCards}>

          {/* Document / OCR */}
          <TouchableOpacity
            style={[styles.cameraCard, styles.cameraCardDocument]}
            onPress={openCamera}
            activeOpacity={0.85}
          >
            <View style={[styles.cameraCardIcon, { backgroundColor: '#00478d20' }]}>
              <FileText color={THEME.primary} size={28} />
            </View>
            <Text style={[styles.cameraCardTitle, { color: THEME.primary }]}>Document</Text>
            <Text style={styles.cameraCardSub}>Scan blood report{'\n'}for OCR extraction</Text>

            {/* Corner reticle decoration */}
            <View style={[styles.miniCorner, styles.topLeft,     { borderColor: THEME.primary }]} />
            <View style={[styles.miniCorner, styles.topRight,    { borderColor: THEME.primary }]} />
            <View style={[styles.miniCorner, styles.bottomLeft,  { borderColor: THEME.primary }]} />
            <View style={[styles.miniCorner, styles.bottomRight, { borderColor: THEME.primary }]} />
          </TouchableOpacity>

          {/* Blood Sample — navigates to dedicated scan.tsx */}
          <TouchableOpacity
            style={[styles.cameraCard, styles.cameraCardBlood]}
            onPress={() => router.push('/scan')}
            activeOpacity={0.85}
          >
            <View style={[styles.cameraCardIcon, { backgroundColor: '#c0392b18' }]}>
              <Microscope color={THEME.blood} size={28} />
            </View>
            <Text style={[styles.cameraCardTitle, { color: THEME.blood }]}>Blood Sample</Text>
            <Text style={styles.cameraCardSub}>Analyze slide for{'\n'}cell morphology</Text>

            {/* Circle reticle decoration */}
            <View style={styles.miniCircle} />
          </TouchableOpacity>
        </View>

        {/* ── File Picker Methods ──────────────────────────────────────── */}
        <Text style={styles.sectionLabel}>FROM STORAGE</Text>
        <View style={styles.uploadMethods}>

          {/* Gallery → Document OCR */}
          <TouchableOpacity style={styles.methodCard} onPress={handlePickImage}>
            <View style={styles.methodIconWrapper}>
              <ImageIcon color={THEME.primary} size={20} />
            </View>
            <View style={styles.methodText}>
              <Text style={styles.methodTitle}>Gallery → Report</Text>
              <Text style={styles.methodSubtitle}>Image → OCR model</Text>
            </View>
          </TouchableOpacity>

          {/* Gallery → Blood ML — navigates to scan.tsx */}
          <TouchableOpacity
            style={[styles.methodCard, styles.methodCardBlood]}
            onPress={() => router.push('/scan')}
          >
            <View style={[styles.methodIconWrapper, { backgroundColor: '#c0392b18' }]}>
              <Microscope color={THEME.blood} size={20} />
            </View>
            <View style={styles.methodText}>
              <Text style={[styles.methodTitle, { color: THEME.blood }]}>Gallery → Slide</Text>
              <Text style={styles.methodSubtitle}>Image → Cell model</Text>
            </View>
          </TouchableOpacity>
        </View>

        <View style={styles.uploadMethods}>
          {/* PDF / document picker */}
          <TouchableOpacity style={styles.methodCard} onPress={handlePickDocument}>
            <View style={[styles.methodIconWrapper, { backgroundColor: '#00478d10' }]}>
              <FolderOpen color={THEME.primary} size={20} />
            </View>
            <View style={styles.methodText}>
              <Text style={styles.methodTitle}>Browse Files</Text>
              <Text style={styles.methodSubtitle}>PDF or image, max 10 MB</Text>
            </View>
          </TouchableOpacity>

          {/* FHIR stub */}
          <TouchableOpacity
            style={styles.methodCard}
            onPress={() => Alert.alert('Coming soon', 'FHIR/HL7 sync is not yet enabled.')}
          >
            <View style={[styles.methodIconWrapper, { backgroundColor: '#cdddff' }]}>
              <BarChart3 color={THEME.secondary} size={20} />
            </View>
            <View style={styles.methodText}>
              <Text style={styles.methodTitle}>Sync Portal</Text>
              <Text style={styles.methodSubtitle}>FHIR / HL7</Text>
            </View>
          </TouchableOpacity>
        </View>

        {/* ── Last Scan Metrics ────────────────────────────────────────── */}
        <View style={styles.metricsCard}>
          <View style={styles.metricsHeader}>
            <View style={styles.metricsTitleRow}>
              <BarChart3 color={THEME.primary} size={20} />
              <Text style={styles.metricsTitle}>Extracted Metrics</Text>
            </View>
            <View style={styles.liveBadge}>
              <Text style={styles.liveText}>LAST SCAN</Text>
            </View>
          </View>

          <View style={styles.metricsList}>
            <MetricItem label="WBC COUNT"  value="8.5"  unit="10³/µL" confidence="100%" progress={0.75} />
            <MetricItem label="HEMOGLOBIN" value="14.2" unit="g/dL"   confidence="98%"  progress={0.5}  />
            <MetricItem label="PLATELETS"  value="245"  unit="10³/µL" confidence="92%"  progress={0.66} />
          </View>

          <View style={styles.alertBox}>
            <AlertTriangle color="#940010" size={20} />
            <View style={styles.alertContent}>
              <Text style={styles.alertTitle}>MANUAL REVIEW REQUIRED</Text>
              <Text style={styles.alertDesc}>
                Patient DOB: 12/05/1984. Partial occlusion detected on laboratory header.
                Verify patient identity before submission.
              </Text>
            </View>
          </View>

          <TouchableOpacity style={styles.confirmButton} onPress={() => router.push('/result')}>
            <Text style={styles.confirmText}>Confirm & Analyze Report</Text>
            <ArrowRight color="#ffffff" size={20} />
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// ─── MetricItem ────────────────────────────────────────────────────────────────
function MetricItem({ label, value, unit, confidence, progress }: {
  label: string; value: string; unit: string; confidence: string; progress: number;
}) {
  return (
    <View style={styles.metricItem}>
      <View style={styles.metricHeaderRow}>
        <Text style={styles.metricLabel}>{label}</Text>
        <Text style={styles.metricConfidence}>{confidence} confidence</Text>
      </View>
      <View style={styles.metricValueRow}>
        <Text style={styles.metricValue}>{value}</Text>
        <Text style={styles.metricUnit}>{unit}</Text>
      </View>
      <View style={styles.progressBar}>
        <View style={[styles.progressFill, { width: `${progress * 100}%` as any }]} />
      </View>
    </View>
  );
}

// ─── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  container:     { flex: 1, backgroundColor: THEME.background },
  scrollContent: { padding: 16, paddingBottom: 100 },

  // Header
  header: {
    height: 64, flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between', paddingHorizontal: 24,
    backgroundColor: '#ffffffcc',
  },
  brand:       { flexDirection: 'row', alignItems: 'center', gap: 12 },
  brandText:   { fontSize: 20, fontWeight: '900', color: THEME.primary, letterSpacing: -1 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  modelIndicator: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#00478d10', paddingHorizontal: 8,
    paddingVertical: 4, borderRadius: 8, gap: 6,
  },
  modelText:  { fontSize: 10, fontWeight: '800', letterSpacing: 0.5 },
  iconButton: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },

  titleSection: { marginBottom: 12, paddingHorizontal: 4 },
  title:        { fontSize: 24, fontWeight: '800', color: THEME.text },
  subtitle:     { fontSize: 14, color: THEME.textSecondary, marginTop: 4 },
  sectionLabel: {
    fontSize: 11, fontWeight: '800', color: THEME.textSecondary,
    letterSpacing: 1.5, marginBottom: 8, paddingHorizontal: 4,
  },

  // ── Camera Cards ────────────────────────────────────────────────────────────
  cameraCards: { flexDirection: 'row', gap: 12, marginBottom: 20 },
  cameraCard: {
    flex: 1, aspectRatio: 0.85, borderRadius: 24, padding: 20,
    justifyContent: 'flex-end', overflow: 'hidden', borderWidth: 1.5,
  },
  cameraCardDocument: { backgroundColor: '#eef2f8', borderColor: '#c0cfe8' },
  cameraCardBlood:    { backgroundColor: '#fdf0ef', borderColor: '#e8b8b4' },
  cameraCardIcon:     { width: 52, height: 52, borderRadius: 16, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  cameraCardTitle:    { fontSize: 16, fontWeight: '800', marginBottom: 4 },
  cameraCardSub:      { fontSize: 12, color: THEME.textSecondary, lineHeight: 17 },

  // Mini reticle decorations on cards
  miniCorner:  { position: 'absolute', width: 18, height: 18 },
  topLeft:     { top: 12,    left: 12,    borderTopWidth: 2,    borderLeftWidth: 2,    borderTopLeftRadius: 4     },
  topRight:    { top: 12,    right: 12,   borderTopWidth: 2,    borderRightWidth: 2,   borderTopRightRadius: 4    },
  bottomLeft:  { bottom: 12, left: 12,    borderBottomWidth: 2, borderLeftWidth: 2,    borderBottomLeftRadius: 4  },
  bottomRight: { bottom: 12, right: 12,   borderBottomWidth: 2, borderRightWidth: 2,   borderBottomRightRadius: 4 },
  miniCircle: {
    position: 'absolute', top: 10, right: 10,
    width: 48, height: 48, borderRadius: 24,
    borderWidth: 2, borderColor: '#c0392b40',
  },

  // ── File methods ────────────────────────────────────────────────────────────
  uploadMethods: { flexDirection: 'row', gap: 12, marginBottom: 12 },
  methodCard: {
    flex: 1, flexDirection: 'row', alignItems: 'center',
    backgroundColor: THEME.cardBg, padding: 14, borderRadius: 20, gap: 12,
  },
  methodCardBlood:    { backgroundColor: '#fdf0ef' },
  methodIconWrapper: {
    width: 40, height: 40, borderRadius: 10,
    backgroundColor: '#00478d20', alignItems: 'center', justifyContent: 'center',
  },
  methodText:     { flex: 1 },
  methodTitle:    { fontSize: 13, fontWeight: '700', color: THEME.text },
  methodSubtitle: { fontSize: 10, color: THEME.textSecondary, marginTop: 1 },

  // ── Camera fullscreen ────────────────────────────────────────────────────────
  cameraContainer: { flex: 1, backgroundColor: '#000' },
  camera:          { flex: 1 },

  cameraTopBar: {
    position: 'absolute', top: 0, left: 0, right: 0,
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', paddingHorizontal: 20, paddingTop: 8,
  },
  modePill: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: '#00478dcc', paddingHorizontal: 14, paddingVertical: 7,
    borderRadius: 99,
  },
  modePillText: { color: '#fff', fontSize: 11, fontWeight: '800', letterSpacing: 1 },

  camIconButton: {
    width: 52, height: 52, borderRadius: 26,
    backgroundColor: '#00000080', alignItems: 'center', justifyContent: 'center',
  },
  camIconButtonActive: { backgroundColor: '#ffffffcc' },

  reticleOverlay: { flex: 1, alignItems: 'center', justifyContent: 'center' },

  reticleRect: {
    width: width * 0.82, aspectRatio: 3 / 4, borderRadius: 12,
    borderWidth: 2, borderColor: '#ffffff80', overflow: 'hidden',
  },
  reticleActive: { borderColor: '#a9c7ff', borderWidth: 3 },

  reticleHint: {
    marginTop: 18, color: '#ffffffcc', fontSize: 14,
    fontWeight: '600', textAlign: 'center',
  },

  scanLine: {
    position: 'absolute', top: 0, left: 0, right: 0, height: 2,
    backgroundColor: THEME.primary,
    shadowColor: THEME.primary, shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9, shadowRadius: 10,
  },

  // Corner brackets inside reticle
  corner: { position: 'absolute', width: 24, height: 24, borderColor: '#a9c7ff' },

  cameraControls: {
    position: 'absolute', bottom: 48, left: 0, right: 0,
    flexDirection: 'row', justifyContent: 'space-around',
    alignItems: 'center', paddingHorizontal: 32,
  },
  shutterOuter: {
    width: 88, height: 88, borderRadius: 44,
    borderWidth: 2, borderColor: '#ffffff4d',
    alignItems: 'center', justifyContent: 'center',
  },
  shutterInner: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: '#ffffff', alignItems: 'center', justifyContent: 'center',
  },
  shutterActive: { backgroundColor: '#ffffff80' },
  shutterCore: {
    width: 64, height: 64, borderRadius: 32,
    borderWidth: 2, borderColor: '#0000001a',
    alignItems: 'center', justifyContent: 'center',
  },

  // ── Metrics card ────────────────────────────────────────────────────────────
  metricsCard: {
    backgroundColor: THEME.surface, borderRadius: 24, padding: 24,
    shadowColor: '#000', shadowOffset: { width: 0, height: 20 },
    shadowOpacity: 0.06, shadowRadius: 40, elevation: 4,
    borderWidth: 1, borderColor: '#ffffff', marginTop: 8, marginBottom: 24,
  },
  metricsHeader: {
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', marginBottom: 24,
  },
  metricsTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  metricsTitle:    { fontSize: 18, fontWeight: '700', color: THEME.text },
  liveBadge:       { backgroundColor: '#00478d15', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 4 },
  liveText:        { fontSize: 10, fontWeight: '700', color: THEME.primary, letterSpacing: 1 },
  metricsList:     { gap: 16, marginBottom: 24 },
  metricItem: {
    backgroundColor: THEME.cardBg, padding: 12, borderRadius: 12,
    borderLeftWidth: 4, borderLeftColor: THEME.primary, gap: 8,
  },
  metricHeaderRow:  { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  metricLabel:      { fontSize: 10, fontWeight: '700', color: THEME.textSecondary, letterSpacing: 1 },
  metricConfidence: { fontSize: 10, fontWeight: '500', color: THEME.primary },
  metricValueRow:   { flexDirection: 'row', alignItems: 'baseline', gap: 8 },
  metricValue:      { fontSize: 24, fontWeight: '900', color: THEME.text },
  metricUnit:       { fontSize: 14, fontWeight: '500', color: THEME.textSecondary },
  progressBar:      { height: 4, backgroundColor: '#e6e8ea', borderRadius: 2, overflow: 'hidden' },
  progressFill:     { height: '100%', backgroundColor: THEME.primary },
  alertBox: {
    backgroundColor: '#94001010', padding: 16, borderRadius: 20,
    flexDirection: 'row', gap: 12, marginBottom: 24,
  },
  alertContent: { flex: 1 },
  alertTitle:   { fontSize: 10, fontWeight: '800', color: '#940010', letterSpacing: 0.5 },
  alertDesc:    { fontSize: 13, color: THEME.textSecondary, lineHeight: 18, marginTop: 4 },
  confirmButton: {
    backgroundColor: THEME.primary, height: 64, borderRadius: 20,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 12,
    shadowColor: THEME.primary, shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.2, shadowRadius: 20,
  },
  confirmText: { fontSize: 16, fontWeight: '700', color: '#ffffff' },
});