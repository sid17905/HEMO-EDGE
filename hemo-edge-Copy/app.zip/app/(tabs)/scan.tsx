import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ActivityIndicator, Alert, Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import {
  Microscope, Zap, Image as ImageIcon, X, FileText,
} from 'lucide-react-native';
import { mlService } from '../../hooks/use-ml-service';

// ─── Types ─────────────────────────────────────────────────────────────────────
type ViewState = 'camera';

const THEME = {
  primary:       '#00478d',
  secondary:     '#4f5f7b',
  background:    '#f7f9fb',
  surface:       '#ffffff',
  text:          '#191c1e',
  textSecondary: '#424752',
  border:        '#e0e3e5',
  cardBg:        '#f2f4f6',
  blood:         '#c0392b',
};

const { width } = Dimensions.get('window');

// ─── Blood Scan Screen ─────────────────────────────────────────────────────────
export default function ScanScreen() {
  const [isCapturing, setIsCapturing] = useState(false);
  const [flashOn,     setFlashOn]     = useState(false);

  const [permission, requestPermission] = useCameraPermissions();
  const cameraRef = useRef<any>(null);

  useEffect(() => {
    (async () => {
      await mlService.initialize();
    })();
  }, []);

  // ─── Helpers ──────────────────────────────────────────────────────────────

  const ensureCameraPermission = async (): Promise<boolean> => {
    if (permission?.granted) return true;
    const result = await requestPermission();
    if (!result.granted) {
      Alert.alert(
        'Camera Permission Required',
        'Please allow camera access in your device settings.',
        [{ text: 'OK' }],
      );
      return false;
    }
    return true;
  };

  /** Capture photo and run cell-ML model */
  const handleCapture = async () => {
    if (isCapturing || !cameraRef.current) return;
    setIsCapturing(true);
    try {
      const photo = await cameraRef.current.takePictureAsync({ quality: 0.85, base64: false });
      console.log('Blood photo captured:', photo.uri);
      await runInference(photo.uri);
    } catch (e) {
      console.error('Capture failed:', e);
      Alert.alert('Capture Failed', 'Could not process the image. Please try again.');
    } finally {
      setIsCapturing(false);
    }
  };

  /** Pick a blood-slide image from gallery */
  const handlePickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission Required', 'Please allow photo library access in settings.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.9,
      allowsEditing: false,
    });
    if (result.canceled || !result.assets?.length) return;
    await runInference(result.assets[0].uri);
  };

  /** Run cell-morphology inference */
  const runInference = async (uri: string) => {
    try {
      const result = await mlService.runInference('cell', { imageUri: uri });
      console.log('CELL Result:', result);
      router.push('/result');
    } catch (e) {
      console.error('Inference failed:', e);
      Alert.alert('Analysis Failed', 'Could not analyze the slide. Please try again.');
    }
  };

  // ─── Camera View ───────────────────────────────────────────────────────────
  return (
    <View style={styles.cameraContainer}>
      <CameraView
        ref={cameraRef}
        style={styles.camera}
        facing="back"
        enableTorch={flashOn}
      >
        {/* Top bar */}
        <SafeAreaView style={styles.cameraTopBar}>
          <TouchableOpacity style={styles.camIconButton} onPress={() => router.back()}>
            <X color="#fff" size={24} />
          </TouchableOpacity>

          <View style={[styles.modePill, styles.modePillBlood]}>
            <Microscope color="#fff" size={14} />
            <Text style={styles.modePillText}>BLOOD SAMPLE</Text>
          </View>

          <TouchableOpacity
            style={[styles.camIconButton, flashOn && styles.camIconButtonActive]}
            onPress={() => setFlashOn(!flashOn)}
          >
            <Zap color={flashOn ? THEME.primary : '#fff'} size={24} />
          </TouchableOpacity>
        </SafeAreaView>

        {/* Circular reticle for blood slide */}
        <View style={styles.reticleOverlay}>
          <View style={[styles.reticleCircle, isCapturing && styles.reticleActive]}>
            {isCapturing && <View style={styles.scanLine} />}
          </View>
          <Text style={styles.reticleHint}>
            Center the blood slide within the circle
          </Text>
        </View>

        {/* Shutter controls */}
        <View style={styles.cameraControls}>
          {/* Gallery shortcut */}
          <TouchableOpacity style={styles.camIconButton} onPress={handlePickImage}>
            <ImageIcon color="#fff" size={24} />
          </TouchableOpacity>

          {/* Main shutter */}
          <View style={styles.shutterOuter}>
            <TouchableOpacity
              style={[styles.shutterInner, isCapturing && styles.shutterActive]}
              onPress={handleCapture}
              disabled={isCapturing}
            >
              <View style={[styles.shutterCore, styles.shutterCoreBlood]}>
                {isCapturing
                  ? <ActivityIndicator color={THEME.blood} size="large" />
                  : <Microscope color={THEME.blood} size={32} />}
              </View>
            </TouchableOpacity>
          </View>

          {/* Navigate to Document scanner */}
          <TouchableOpacity
            style={styles.camIconButton}
            onPress={() => router.replace('/scanner')}
          >
            <FileText color="#fff" size={24} />
          </TouchableOpacity>
        </View>
      </CameraView>
    </View>
  );
}

// ─── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  cameraContainer: { flex: 1, backgroundColor: '#000' },
  camera:          { flex: 1 },

  cameraTopBar: {
    position: 'absolute', top: 0, left: 0, right: 0,
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', paddingHorizontal: 20, paddingTop: 8,
  },

  modePill: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: '#00478dcc', paddingHorizontal: 14, paddingVertical: 7,
    borderRadius: 99,
  },
  modePillBlood: { backgroundColor: '#c0392bcc' },
  modePillText:  { color: '#fff', fontSize: 11, fontWeight: '800', letterSpacing: 1 },

  camIconButton: {
    width: 52, height: 52, borderRadius: 26,
    backgroundColor: '#00000080', alignItems: 'center', justifyContent: 'center',
  },
  camIconButtonActive: { backgroundColor: '#ffffffcc' },

  reticleOverlay: { flex: 1, alignItems: 'center', justifyContent: 'center' },

  reticleCircle: {
    width: width * 0.72, height: width * 0.72,
    borderRadius: width * 0.36,
    borderWidth: 2, borderColor: '#ffffff80', overflow: 'hidden',
  },
  reticleActive: { borderColor: '#a9c7ff', borderWidth: 3 },

  reticleHint: {
    marginTop: 18, color: '#ffffffcc', fontSize: 14,
    fontWeight: '600', textAlign: 'center',
  },

  scanLine: {
    position: 'absolute', top: 0, left: 0, right: 0, height: 2,
    backgroundColor: THEME.blood,
    shadowColor: THEME.blood, shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9, shadowRadius: 10,
  },

  cameraControls: {
    position: 'absolute', bottom: 48, left: 0, right: 0,
    flexDirection: 'row', justifyContent: 'space-around',
    alignItems: 'center', paddingHorizontal: 32,
  },

  shutterOuter: {
    width: 88, height: 88, borderRadius: 44,
    borderWidth: 2, borderColor: '#ffffff4d',
    alignItems: 'center', justifyContent: 'center',
  },
  shutterInner: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: '#ffffff', alignItems: 'center', justifyContent: 'center',
  },
  shutterActive: { backgroundColor: '#ffffff80' },
  shutterCore: {
    width: 64, height: 64, borderRadius: 32,
    borderWidth: 2, borderColor: '#0000001a',
    alignItems: 'center', justifyContent: 'center',
  },
  shutterCoreBlood: { borderColor: '#c0392b33' },
});