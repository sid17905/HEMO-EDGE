import React from 'react';
import { View, Text, StyleSheet,TouchableOpacity, Image } from 'react-native';
import { router } from 'expo-router';                          // ✅ FIXED: expo-router
import { Settings, CheckCircle, ArrowRight, RefreshCw } from 'lucide-react-native';
// ✅ Correct
import { SafeAreaView } from 'react-native-safe-area-context';
const THEME = {
  primary: '#00478d',
  secondary: '#4f5f7b',
  background: '#f7f9fb',
  surface: '#ffffff',
  text: '#191c1e',
  textSecondary: '#424752',
  success: '#006d3a',
};

export default function ResultScreen() {                       // ✅ FIXED: no { navigation } prop
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.iconButton} onPress={() => router.back()}>
          <RefreshCw color={THEME.primary} size={24} />
        </TouchableOpacity>
        <Text style={styles.brandText}>HEMO-EDGE</Text>
        <TouchableOpacity style={styles.iconButton}>
          <Settings color={THEME.textSecondary} size={24} />
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        <View style={styles.visualSection}>
          <View style={styles.imageContainer}>
            <Image
              source={{ uri: 'https://picsum.photos/seed/cells/800/800' }}
              style={styles.cellsImg}
            />
            <View style={styles.overlay}>
              <View style={styles.circleOuter}>
                <View style={styles.circleInner}>
                  <CheckCircle color={THEME.primary} size={64} strokeWidth={2.5} />
                </View>
              </View>
            </View>
            <View style={[styles.corner, styles.topLeft]} />
            <View style={[styles.corner, styles.topRight]} />
            <View style={[styles.corner, styles.bottomLeft]} />
            <View style={[styles.corner, styles.bottomRight]} />
          </View>
        </View>

        <View style={styles.textSection}>
          <View style={styles.badge}>
            <Text style={styles.badgeText}>ANALYSIS COMPLETE</Text>
          </View>
          <Text style={styles.title}>Ready for Review</Text>
          <Text style={styles.desc}>
            System has successfully processed all cellular samples and generated the diagnostic report.
          </Text>

          <View style={styles.progressSection}>
            <View style={styles.progressHeader}>
              <Text style={styles.progressLabel}>STATUS: 100% COMPLETED</Text>
              <Text style={styles.progressPercent}>100%</Text>
            </View>
            <View style={styles.progressBar}>
              <View style={styles.progressFill} />
            </View>
            <View style={styles.stepsRow}>
              <Step label="EXTRACTION" />
              <Step label="CLASSIFICATION" />
              <Step label="REPORT GEN" />
            </View>
          </View>

          {/* ✅ FIXED: navigate back to history (explore tab) to view results list,
              or replace with your real AnalysisDetail screen once you create it */}
          <TouchableOpacity
            style={styles.primaryButton}
            onPress={() => router.push('/(tabs)/explore')}
          >
            <Text style={styles.primaryButtonText}>View Results</Text>
            <ArrowRight color="#ffffff" size={20} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.secondaryButton}
            onPress={() => router.push('/(tabs)/scanner')}
          >
            <Text style={styles.secondaryButtonText}>Scan Another Report</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

function Step({ label }: { label: string }) {
  return (
    <View style={styles.step}>
      <CheckCircle color={THEME.primary} size={14} />
      <Text style={styles.stepText}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: THEME.background },
  header: {
    height: 64, flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between', paddingHorizontal: 24,
  },
  brandText: { fontSize: 20, fontWeight: '900', color: THEME.primary, letterSpacing: -1 },
  iconButton: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  content: { flex: 1, padding: 24, justifyContent: 'center', gap: 40 },
  visualSection: { alignItems: 'center' },
  imageContainer: {
    width: '100%', maxWidth: 340, aspectRatio: 1, borderRadius: 40,
    backgroundColor: '#ffffff', overflow: 'hidden',
    shadowColor: '#000', shadowOffset: { width: 0, height: 20 },
    shadowOpacity: 0.06, shadowRadius: 40, elevation: 4,
  },
  cellsImg: { width: '100%', height: '100%', opacity: 0.3 },
  overlay: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  circleOuter: {
    width: '70%', aspectRatio: 1, borderRadius: 999,
    borderWidth: 4, borderColor: '#00478d33', alignItems: 'center', justifyContent: 'center',
  },
  circleInner: {
    width: '75%', aspectRatio: 1, borderRadius: 999,
    backgroundColor: '#00478d0d', alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: '#00478d1a',
  },
  corner: { position: 'absolute', width: 32, height: 32, borderColor: '#00478d66' },
  topLeft: { top: 24, left: 24, borderTopWidth: 2, borderLeftWidth: 2, borderTopLeftRadius: 8 },
  topRight: { top: 24, right: 24, borderTopWidth: 2, borderRightWidth: 2, borderTopRightRadius: 8 },
  bottomLeft: { bottom: 24, left: 24, borderBottomWidth: 2, borderLeftWidth: 2, borderBottomLeftRadius: 8 },
  bottomRight: { bottom: 24, right: 24, borderBottomWidth: 2, borderRightWidth: 2, borderBottomRightRadius: 8 },
  textSection: { gap: 8 },
  badge: {
    backgroundColor: '#dcfce7', paddingHorizontal: 12, paddingVertical: 4,
    borderRadius: 99, alignSelf: 'flex-start', marginBottom: 8,
  },
  badgeText: { fontSize: 10, fontWeight: '800', color: '#15803d', letterSpacing: 2 },
  title: { fontSize: 40, fontWeight: '800', color: THEME.text, letterSpacing: -1 },
  desc: { fontSize: 18, color: THEME.textSecondary, lineHeight: 24, marginBottom: 16 },
  progressSection: { gap: 16, marginBottom: 24 },
  progressHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  progressLabel: { fontSize: 12, fontWeight: '600', color: '#00478d99', letterSpacing: 1 },
  progressPercent: { fontSize: 24, fontWeight: '800', color: THEME.primary },
  progressBar: { height: 12, backgroundColor: '#eceef0', borderRadius: 6, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: THEME.primary, width: '100%' },
  stepsRow: { flexDirection: 'row', gap: 16 },
  step: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  stepText: { fontSize: 10, fontWeight: '700', color: THEME.primary, letterSpacing: 1 },
  primaryButton: {
    backgroundColor: THEME.primary, height: 64, borderRadius: 20,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 12,
    shadowColor: THEME.primary, shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.2, shadowRadius: 20,
  },
  primaryButtonText: { fontSize: 18, fontWeight: '700', color: '#ffffff' },
  secondaryButton: {
    height: 52, borderRadius: 20, alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: THEME.primary,
  },
  secondaryButtonText: { fontSize: 16, fontWeight: '700', color: THEME.primary },
});