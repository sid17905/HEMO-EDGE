import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, Dimensions } from 'react-native';
import { ChevronLeft, AlertTriangle, BarChart3, FileText, Lock, ArrowRight, Download, Maximize2, Layers, Microscope } from 'lucide-react-native';
// ✅ Correct
import { SafeAreaView } from 'react-native-safe-area-context';
const THEME = {
  primary: '#00478d',
  secondary: '#4f5f7b',
  background: '#f7f9fb',
  surface: '#ffffff',
  text: '#191c1e',
  textSecondary: '#424752',
  error: '#ba1a1a',
  errorContainer: '#bb1b21',
};

const { width } = Dimensions.get('window');

export default function AnalysisDetailScreen({ navigation }: any) {
  const [viewMode, setViewMode] = useState<'original' | 'heatmap'>('heatmap');

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <ChevronLeft color={THEME.text} size={24} />
        </TouchableOpacity>
        <View style={styles.brand}>
          <FileText color={THEME.primary} size={20} />
          <Text style={styles.brandText}>HEMO-EDGE</Text>
        </View>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.titleSection}>
          <Text style={styles.caseId}>CASE ID: #HE-99281-B</Text>
          <Text style={styles.title}>Diagnostic Analysis</Text>
        </View>

        <View style={styles.alertCard}>
          <View style={styles.alertHeader}>
            <AlertTriangle color="#ffffff" size={32} fill="#ffffff" />
            <Text style={styles.alertLabel}>CRITICAL ALERT</Text>
          </View>
          <Text style={styles.alertTitle}>Malignant Cell Morphology</Text>
          <Text style={styles.alertDesc}>
            AI synthesis indicates a high probability of acute lymphoblastic progression. Immediate clinical review of the leukocyte population is advised.
          </Text>
          <View style={styles.alertIconBg}>
            <Microscope color="#ffffff" size={180} opacity={0.1} />
          </View>
        </View>

        <View style={styles.metricsRow}>
          <View style={styles.metricCard}>
            <Text style={styles.metricLabel}>CONFIDENCE SCORE</Text>
            <View style={styles.metricValueRow}>
              <Text style={styles.metricValue}>98.4%</Text>
              <Text style={styles.metricSub}>High confidence</Text>
            </View>
            <View style={styles.progressBar}>
              <View style={[styles.progressFill, { width: '98.4%' }]} />
            </View>
          </View>

          <View style={styles.metricCard}>
            <Text style={styles.metricLabel}>CELL COUNT (DETECTED)</Text>
            <Text style={styles.metricValue}>1,422</Text>
            <Text style={styles.metricSub}>±12 margin of error</Text>
          </View>
        </View>

        <View style={styles.visualSection}>
          <View style={styles.visualHeader}>
            <View>
              <Text style={styles.visualTitle}>Visual Validation</Text>
              <Text style={styles.visualSubtitle}>Microscopic input vs AI-generated thermal variance mapping</Text>
            </View>
            <View style={styles.toggleRow}>
              <TouchableOpacity 
                style={[styles.toggleBtn, viewMode === 'original' && styles.toggleBtnActive]}
                onPress={() => setViewMode('original')}
              >
                <Text style={[styles.toggleText, viewMode === 'original' && styles.toggleTextActive]}>Original</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.toggleBtn, viewMode === 'heatmap' && styles.toggleBtnActive]}
                onPress={() => setViewMode('heatmap')}
              >
                <Text style={[styles.toggleText, viewMode === 'heatmap' && styles.toggleTextActive]}>Heatmap Overlay</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.imageGrid}>
            <View style={styles.imageWrapper}>
              <View style={styles.imageContainer}>
                <Image 
                  source={{ uri: 'https://picsum.photos/seed/blood1/800/450' }} 
                  style={styles.mainImg}
                />
                <View style={styles.imgBadge}>
                  <Text style={styles.imgBadgeText}>INPUT: CHANNEL A</Text>
                </View>
              </View>
              <View style={styles.imageFooter}>
                <Text style={styles.imageFooterText}>Magnification: 1000x (Oil)</Text>
                <Maximize2 color={THEME.primary} size={16} />
              </View>
            </View>

            <View style={styles.imageWrapper}>
              <View style={styles.imageContainer}>
                <Image 
                  source={{ uri: 'https://picsum.photos/seed/heatmap1/800/450' }} 
                  style={styles.mainImg}
                />
                <View style={[styles.imgBadge, { backgroundColor: '#94001099' }]}>
                  <Text style={styles.imgBadgeText}>INFERENCE: NEURAL-MAP</Text>
                </View>
              </View>
              <View style={styles.imageFooter}>
                <Text style={styles.imageFooterText}>Detection Threshold: 0.85</Text>
                <Layers color={THEME.primary} size={16} />
              </View>
            </View>
          </View>
        </View>

        <View style={styles.observationsCard}>
          <View style={styles.obsHeader}>
            <FileText color={THEME.primary} size={20} />
            <Text style={styles.obsTitle}>AI Key Observations</Text>
          </View>
          <View style={styles.obsList}>
            <View style={styles.obsItem}>
              <View style={[styles.dot, { backgroundColor: THEME.error }]} />
              <View style={styles.obsContent}>
                <Text style={styles.obsItemTitle}>Atypical Nuclear Enlargement</Text>
                <Text style={styles.obsItemDesc}>Detected in 42% of leukocytes across all scanned regions.</Text>
              </View>
            </View>
            <View style={styles.obsItem}>
              <View style={[styles.dot, { backgroundColor: THEME.primary }]} />
              <View style={styles.obsContent}>
                <Text style={styles.obsItemTitle}>Chromatin Patterning Shift</Text>
                <Text style={styles.obsItemDesc}>Dense hyperchromasia observed, consistent with pre-malignant states.</Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.contextCard}>
          <Text style={styles.contextTitle}>Patient Context</Text>
          <View style={styles.contextGrid}>
            <ContextItem label="ANALYZED ON" value="Oct 24, 2023 | 14:22" />
            <ContextItem label="SCAN MODE" value="Deep Spectrum Scan" />
            <ContextItem label="SPECIMEN TYPE" value="Peripheral Smear" />
            <ContextItem label="PROCESSING LATENCY" value="1.2s (GPU Accel)" />
          </View>
          <View style={styles.contextFooter}>
            <Text style={styles.statusText}>Status: Finalized</Text>
            <Lock color="#727783" size={16} fill="#727783" />
          </View>
        </View>
      </ScrollView>

      <TouchableOpacity style={styles.fab}>
        <Download color="#ffffff" size={24} />
        <Text style={styles.fabText}>Download PDF</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

function ContextItem({ label, value }: any) {
  return (
    <View style={styles.contextItem}>
      <Text style={styles.contextLabel}>{label}</Text>
      <Text style={styles.contextValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: THEME.background,
  },
  header: {
    height: 64,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 24,
    backgroundColor: '#ffffffcc',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  brand: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  brandText: {
    fontSize: 18,
    fontWeight: '900',
    color: THEME.primary,
    letterSpacing: -0.5,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 120,
  },
  titleSection: {
    paddingVertical: 24,
    paddingHorizontal: 8,
  },
  caseId: {
    fontSize: 12,
    fontWeight: '600',
    color: THEME.primary,
    letterSpacing: 2,
    marginBottom: 8,
  },
  title: {
    fontSize: 36,
    fontWeight: '800',
    color: THEME.text,
    letterSpacing: -1,
  },
  alertCard: {
    backgroundColor: THEME.errorContainer,
    borderRadius: 24,
    padding: 32,
    marginBottom: 24,
    overflow: 'hidden',
    shadowColor: THEME.errorContainer,
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.1,
    shadowRadius: 20,
    elevation: 4,
  },
  alertHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 16,
  },
  alertLabel: {
    fontSize: 16,
    fontWeight: '700',
    color: '#ffffffcc',
    letterSpacing: 3,
  },
  alertTitle: {
    fontSize: 44,
    fontWeight: '800',
    color: '#ffffff',
    lineHeight: 48,
    marginBottom: 16,
  },
  alertDesc: {
    fontSize: 18,
    color: '#ffffffcc',
    lineHeight: 26,
  },
  alertIconBg: {
    position: 'absolute',
    right: -60,
    bottom: -60,
  },
  metricsRow: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 24,
  },
  metricCard: {
    flex: 1,
    backgroundColor: THEME.surface,
    borderRadius: 20,
    padding: 20,
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.03,
    shadowRadius: 10,
    elevation: 1,
  },
  metricLabel: {
    fontSize: 10,
    fontWeight: '700',
    color: THEME.textSecondary,
    letterSpacing: 1,
    marginBottom: 4,
  },
  metricValueRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 8,
  },
  metricValue: {
    fontSize: 32,
    fontWeight: '800',
    color: THEME.primary,
  },
  metricSub: {
    fontSize: 12,
    fontWeight: '600',
    color: THEME.primary + '99',
  },
  progressBar: {
    height: 6,
    backgroundColor: '#eceef0',
    borderRadius: 3,
    marginTop: 12,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: THEME.primary,
  },
  visualSection: {
    backgroundColor: '#f2f4f6',
    borderRadius: 24,
    padding: 24,
    marginBottom: 24,
  },
  visualHeader: {
    flexDirection: 'column',
    gap: 16,
    marginBottom: 32,
  },
  visualTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: THEME.text,
  },
  visualSubtitle: {
    fontSize: 14,
    color: THEME.textSecondary,
  },
  toggleRow: {
    flexDirection: 'row',
    gap: 8,
  },
  toggleBtn: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#e0e3e5',
  },
  toggleBtnActive: {
    backgroundColor: THEME.primary,
  },
  toggleText: {
    fontSize: 13,
    fontWeight: '700',
    color: THEME.textSecondary,
  },
  toggleTextActive: {
    color: '#ffffff',
  },
  imageGrid: {
    gap: 32,
  },
  imageWrapper: {
    gap: 12,
  },
  imageContainer: {
    aspectRatio: 16 / 9,
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: '#000',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.2,
    shadowRadius: 20,
  },
  mainImg: {
    width: '100%',
    height: '100%',
  },
  imgBadge: {
    position: 'absolute',
    top: 16,
    left: 16,
    backgroundColor: '#00000066',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 4,
  },
  imgBadgeText: {
    color: '#ffffff',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.5,
  },
  imageFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 8,
  },
  imageFooterText: {
    fontSize: 14,
    fontWeight: '600',
    color: THEME.textSecondary,
  },
  observationsCard: {
    backgroundColor: THEME.surface,
    borderRadius: 24,
    padding: 32,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.03,
    shadowRadius: 30,
    elevation: 2,
  },
  obsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 24,
  },
  obsTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: THEME.text,
  },
  obsList: {
    gap: 24,
  },
  obsItem: {
    flexDirection: 'row',
    gap: 16,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginTop: 8,
  },
  obsContent: {
    flex: 1,
    gap: 4,
  },
  obsItemTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: THEME.text,
  },
  obsItemDesc: {
    fontSize: 14,
    color: THEME.textSecondary,
    lineHeight: 20,
  },
  contextCard: {
    backgroundColor: '#f2f4f6',
    borderRadius: 24,
    padding: 32,
  },
  contextTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: THEME.text,
    marginBottom: 24,
  },
  contextGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 24,
  },
  contextItem: {
    width: '45%',
    gap: 4,
  },
  contextLabel: {
    fontSize: 10,
    fontWeight: '700',
    color: THEME.textSecondary,
    letterSpacing: 1.5,
  },
  contextValue: {
    fontSize: 14,
    fontWeight: '700',
    color: THEME.text,
  },
  contextFooter: {
    marginTop: 32,
    paddingTop: 24,
    borderTopWidth: 1,
    borderTopColor: '#e0e3e5',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  statusText: {
    fontSize: 14,
    fontWeight: '600',
    color: THEME.primary,
  },
  fab: {
    position: 'absolute',
    bottom: 32,
    right: 24,
    backgroundColor: THEME.primary,
    height: 64,
    paddingHorizontal: 32,
    borderRadius: 32,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    shadowColor: THEME.primary,
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 8,
  },
  fabText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '700',
  },
});
